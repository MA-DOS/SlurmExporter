# SlurmExporter
This repository holds an exporter for some slurm metrics.
